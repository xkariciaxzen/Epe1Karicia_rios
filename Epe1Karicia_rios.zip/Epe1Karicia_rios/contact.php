<?php
error_reporting(0);
$host = "localhost";
$dbname = "techsolutions";
$dbuser = "root";
$password = "";

try {
    $conn = new mysqli($host, $dbuser, $password, $dbname);
    if ($conn->connect_error) {
        die("Problemas con la conexión: " . $conn->connect_error);
    }
} catch (Exception $ex) {
    echo $conn->connect_error;
}

if ($_POST['flag'] == 1) {
    // Asegúrate de que los nombres de los campos coincidan con los nombres en el formulario
    $insertSql = "INSERT INTO contacto (nombre, email, asunto, mensaje) VALUES ('" . $_POST['nombre'] . "','" . $_POST['email'] . "','" . $_POST['asunto'] . "','" . $_POST['mensaje'] . "')";
    mysqli_query($conn, $insertSql);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Contacto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        input[type="text"], input[type="email"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Contacto</h2>
        <form action="" method="post">
            <input type="text" name="nombre" placeholder="Nombre" required><br>
            <input type="email" name="email" placeholder="Correo Electrónico" required><br>
            <input type="text" name="asunto" placeholder="Asunto" required><br>
            <textarea name="mensaje" placeholder="Escribe tu mensaje." rows="4" required></textarea><br>
            <input type="hidden" name="flag" value="1">
            <input type="submit" value="Enviar">
        </form>
    </div>
</body>
</html>
