<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="TechSolutions - Soluciones Tecnológicas a Medida" />
    <meta name="author" content="TechSolutions" />
    <title>TechSolutions - Innovación a tu Alcance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body>
    <!-- Responsive navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container px-5">
            <a class="navbar-brand" href="#!">TechSolutions</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="#!">Inicio</a></li>
                    <li class="nav-item"><a class="nav-link" href="service.php">Servicios</a></li>
                    <li class="nav-item"><a class="nav-link" href="team.php">Nosotros</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contacto</a></li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Header-->
    <header class="bg-dark py-5">
        <div class="container px-5">
            <div class="row gx-5 justify-content-center">
                <div class="col-lg-6">
                    <div class="text-center my-5">
                        <h1 class="display-5 fw-bolder text-white mb-2">Soluciones Tecnológicas a Medida</h1>
                        <p class="lead text-white-50 mb-4">En TechSolutions, transformamos tus ideas en productos digitales innovadores y eficientes, listos para el éxito.</p>
                        <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
                            <a class="btn btn-primary btn-lg px-4 me-sm-3" href="#services">Conoce nuestros servicios</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    
    <!-- Services section (Customizado)-->
    <section class="py-5 border-bottom" id="services">
        <div class="container px-5 my-5">
            <div class="row gx-5">
                <div class="col-lg-4 mb-5 mb-lg-0">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-code-slash"></i></div>
                    <h2 class="h4 fw-bolder">Desarrollo de Software a Medida</h2>
                    <p>Diseñamos y desarrollamos soluciones de software personalizadas que se ajustan a las necesidades específicas de tu empresa, optimizando tus procesos y mejorando la eficiencia.</p>
                    <a class="text-decoration-none" href="service.php">
                        Más información
                        <i class="bi bi-arrow-right"></i>
                    </a>
                </div>
                <div class="col-lg-4 mb-5 mb-lg-0">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-bar-chart-fill"></i></div>
                    <h2 class="h4 fw-bolder">Auditorías de Sistemas</h2>
                    <p>Realizamos auditorías exhaustivas de tus sistemas para garantizar la calidad, seguridad y rendimiento de tus aplicaciones, minimizando riesgos y potenciando la productividad.</p>
                    <a class="text-decoration-none" href="service.php">
                        Más información
                        <i class="bi bi-arrow-right"></i>
                    </a>
                </div>
                <div class="col-lg-4">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-shield-lock"></i></div>
                    <h2 class="h4 fw-bolder">Consultoría en Ciberseguridad</h2>
                    <p>Ofrecemos asesoría para proteger tus sistemas de amenazas digitales, asegurando la privacidad y la integridad de la información de tu empresa.</p>
                    <a class="text-decoration-none" href="service.php">
                        Más información
                        <i class="bi bi-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>
    
    
    <!-- Contact section-->
    <section class="bg-light py-5">
        <div class="container px-5 my-5">
            <div class="text-center mb-5">
                <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-envelope"></i></div>
                <h2 class="fw-bolder">Contáctanos</h2>
                <p class="lead mb-0">Estamos aquí para ayudarte a llevar tu negocio al siguiente nivel.</p>
            </div>
            <!-- Contact form goes here -->
        </div>
    </section>

    <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
</body>
</html>
