<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .team-card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Nuestro Equipo</h2>
            <p class="lead">Conoce a las personas que hacen que todo esto sea posible.</p>
        </div>
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="card team-card">
                    <img src="https://img.freepik.com/free-photo/worldface-spanish-man-white-background_53876-139733.jpg?size=626&ext=jpg&ga=GA1.1.2008272138.1723593600&semt=ais_hybrid" alt="Foto de juan hevia" class="card-img-top">
                    <div class="card-body text-center">
                        <h5 class="card-title">juan hevia</h5>
                        <p class="card-text">CEO y Fundador</p>
                        <p class="text-muted">juan lidera la empresa con una visión clara y una pasión por la tecnología innovadora.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card team-card">
                    <img src="https://img.freepik.com/fotos-premium/desarrollador-software-profesional-que-trabaja-software-linea_1288657-143413.jpg" alt="Foto de ignacio toro" class="card-img-top">
                    <div class="card-body text-center">
                        <h5 class="card-title">ignacio toro</h5>
                        <p class="card-text">Director de Tecnología</p>
                        <p class="text-muted">ignacio es el cerebro detrás de nuestras soluciones tecnológicas, siempre a la vanguardia.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card team-card">
                    <img src="https://e00-elmundo.uecdn.es/assets/multimedia/imagenes/2024/06/06/17176756089293.png" alt="Foto de eduardo muñoz" class="card-img-top">
                    <div class="card-body text-center">
                        <h5 class="card-title">eduardo muñoz</h5>
                        <p class="card-text">Jefe de Desarrollo</p>
                        <p class="text-muted">eduardo coordina a nuestro equipo de desarrollo, asegurándose de que todo funcione sin problemas.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
