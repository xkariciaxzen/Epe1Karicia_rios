<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios - TechSolutions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
</head>
<body>
    <section class="pricing-section bg-light py-5 border-bottom">
        <div class="container px-5 my-5">
            <div class="text-center mb-5">
                <h2 class="fw-bolder">Servicios que ofrecemos </h2>
                <p class="lead mb-0">Escoge el plan que mejor se adapta a tu negocio</p>
            </div>
            <div class="row gx-5 justify-content-center">
    <!-- Pricing card small business -->
    <div class="col-lg-4 col-xl-3">
        <div class="card mb-5 mb-xl-0">
            <div class="card-body p-5">
                <div class="small text-uppercase fw-bold text-muted">Pequeña empresa</div>
                <div class="mb-3">
                    <span class="display-4 fw-bold">$49</span>
                    <span class="text-muted">/ mes</span>
                </div>
                <ul class="list-unstyled mb-4">
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Hasta 10 usuarios
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        10GB de almacenamiento
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Proyectos ilimitados
                    </li>
                    <li class="text-muted">
                        <i class="bi bi-x"></i>
                        Soporte dedicado
                    </li>
                </ul>
                <div class="d-grid"><a class="btn btn-outline-primary" href="">Seleccionar plan</a></div>
            </div>
        </div>
    </div>

    <!-- Pricing card medium business -->
    <div class="col-lg-4 col-xl-3">
        <div class="card mb-5 mb-xl-0">
            <div class="card-body p-5">
                <div class="small text-uppercase fw-bold text-muted">Mediana empresa</div>
                <div class="mb-3">
                    <span class="display-4 fw-bold">$99</span>
                    <span class="text-muted">/ mes</span>
                </div>
                <ul class="list-unstyled mb-4">
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Hasta 50 usuarios
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        50GB de almacenamiento
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Proyectos ilimitados
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Soporte 24/7
                    </li>
                </ul>
                <div class="d-grid"><a class="btn btn-outline-primary" href="">Seleccionar plan</a></div>
            </div>
        </div>
    </div>

    <!-- Pricing card enterprise -->
    <div class="col-lg-4 col-xl-3">
        <div class="card">
            <div class="card-body p-5">
                <div class="small text-uppercase fw-bold text-muted">Corporativo</div>
                <div class="mb-3">
                    <span class="display-4 fw-bold">$199</span>
                    <span class="text-muted">/ mes</span>
                </div>
                <ul class="list-unstyled mb-4">
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Usuarios ilimitados
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Almacenamiento ilimitado
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Proyectos privados y públicos
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-check text-primary"></i>
                        Soporte dedicado 24/7
                    </li>
                </ul>
                <div class="d-grid"><a class="btn btn-outline-primary" href="#!">Seleccionar plan</a></div>
            </div>
        </div>
    </div>
</div>

    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
